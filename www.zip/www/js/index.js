/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener('deviceready', onDeviceReady, false);
function onDeviceReady() {
    // Cordova is now initialized. Have fun!
    $("#create").click(createFile());
    $("#read").click(readFile());
    $("#write").click(writeFile());
    watchAcceleration();
    function watchAcceleration() {
        var accelerometerOptions = {
           frequency: 300
        }
        var watchID = navigator.accelerometer.watchAcceleration(
           accelerometerSuccess, accelerometerError, accelerometerOptions);
     
        function accelerometerSuccess(acceleration) {
            $('#test1').html(acceleration.x.toFixed(2));
            $('#test2').html(acceleration.y.toFixed(2));
            $('#test3').html(acceleration.z.toFixed(2));     
           setTimeout(function() {
              navigator.accelerometer.clearWatch(watchID);
           }, 100);
        };
        function accelerometerError() {
           alert('onError!');
        };
         
     }
    //  File System
     function createFile() {
        var type = window.TEMPORARY;
        var size = 5*1024*1024;
        window.requestFileSystem(type, size, successCallback, errorCallback)
     
        function successCallback(fs) {
           fs.root.getFile('log.txt', {create: true, exclusive: true}, function(fileEntry) {
              alert('File creation successfull!')
           }, errorCallback);
        }
     
        function errorCallback(error) {
           alert("ERROR: " + error.code)
        }
         
     }
     function writeFile() {
        var type = window.TEMPORARY;
        var size = 5*1024*1024;
        window.requestFileSystem(type, size, successCallback, errorCallback)
     
        function successCallback(fs) {
           fs.root.getFile('log.txt', {create: true}, function(fileEntry) {
     
              fileEntry.createWriter(function(fileWriter) {
                 fileWriter.onwriteend = function(e) {
                    alert('Write completed.');
                 };
     
                 fileWriter.onerror = function(e) {
                    alert('Write failed: ' + e.toString());
                 };
     
                 var blob = new Blob(['Lorem Ipsum'], {type: 'text/plain'});
                 fileWriter.write(blob);
              }, errorCallback);
           }, errorCallback);
        }
     
        function errorCallback(error) {
           alert("ERROR: " + error.code)
        }
     }
     function readFile() {
        var type = window.TEMPORARY;
        var size = 5*1024*1024;
        window.requestFileSystem(type, size, successCallback, errorCallback)
     
        function successCallback(fs) {
           fs.root.getFile('log.txt', {}, function(fileEntry) {
     
              fileEntry.file(function(file) {
                 var reader = new FileReader();
     
                 reader.onloadend = function(e) {
                    var txtArea = document.getElementById('textarea');
                    txtArea.value = this.result;
                 };
                 reader.readAsText(file);
              }, errorCallback);
           }, errorCallback);
        }
     
        function errorCallback(error) {
           alert("ERROR: " + error.code)
        }
     }	
    function removeFile() {
        var type = window.TEMPORARY;
        var size = 5*1024*1024;
        window.requestFileSystem(type, size, successCallback, errorCallback)
     
        function successCallback(fs) {
           fs.root.getFile('log.txt', {create: false}, function(fileEntry) {
     
              fileEntry.remove(function() {
                 alert('File removed.');
              }, errorCallback);
           }, errorCallback);
        }
     
        function errorCallback(error) {
           alert("ERROR: " + error.code)
        }
     }	

function listDir(path){
    window.resolveLocalFileSystemURL(path,
      function (fileSystem) {
        var reader = fileSystem.createReader();
        reader.readEntries(
          function (entries) {
            console.log(entries);
          },
          function (err) {
            console.log(err);
          }
        );
      }, function (err) {
        console.log(err);
      }
    );
  }
  //example: list of www/audio/ folder in cordova/ionic app.
  listDir(cordova.file.applicationDirectory + "www/audio/");
    console.log('Running cordova-' + cordova.platformId + '@' + cordova.version);
    
}
// var el = document.querySelector('.tabs');
// var instance = M.Tabs.init(el, {});
  $(document).ready(function(){
    $('.fixed-action-btn').floatingActionButton();
  });
 
 